﻿namespace DungeonsAndCodeWizards.Characters.Enums
{
    public enum Faction
    {
        CSharp, Java
    }
}