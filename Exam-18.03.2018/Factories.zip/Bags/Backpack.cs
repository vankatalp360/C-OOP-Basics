﻿namespace DungeonsAndCodeWizards.Bags
{
    public class Backpack : Bag
    {
        public Backpack() 
            :base(100)
        {
        }
    }
}