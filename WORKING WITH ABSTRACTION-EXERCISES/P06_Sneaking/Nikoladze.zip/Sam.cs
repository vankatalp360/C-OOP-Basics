﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_Sneaking
{
    public class Sam
    {
        public int Row { get; set; }
        public int Col { get; set; }

        public Sam(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
}
