﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P06_Sneaking
{
    public class Nikoladze
    {
        public int Row { get; set; }
        public int Col { get; set; }

        public Nikoladze(int row, int col)
        {
            Row = row;
            Col = col;
        }
    }
}
