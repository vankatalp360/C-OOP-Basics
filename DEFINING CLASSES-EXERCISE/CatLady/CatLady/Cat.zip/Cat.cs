﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cat
{
    public string Name { get; set; }
}
