﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBrowsable
{
    void Browse(string site);
}
