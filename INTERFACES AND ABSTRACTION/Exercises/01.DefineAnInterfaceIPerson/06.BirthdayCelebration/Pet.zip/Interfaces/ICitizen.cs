﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ICitizen
{
    string Name { get; set; }
    int Age { get; set; }

}
