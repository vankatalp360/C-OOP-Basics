﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IBirthdate
{
    string Birthdate { get; set; }
}
