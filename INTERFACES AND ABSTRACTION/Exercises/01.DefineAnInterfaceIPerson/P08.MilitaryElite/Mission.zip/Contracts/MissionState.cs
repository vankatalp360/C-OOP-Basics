﻿namespace P08.MilitaryElite.Contracts
{
    public enum MissionState
    {
        inProgress, Finished
    }
}