﻿namespace P08.MilitaryElite.Contracts
{
    public interface IPrivate : ISoldier    
    {
        decimal Salary { get; }
    }
}