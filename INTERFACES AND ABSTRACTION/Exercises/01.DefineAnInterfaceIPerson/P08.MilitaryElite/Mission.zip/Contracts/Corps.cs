﻿namespace P08.MilitaryElite.Contracts
{
    public enum Corps
    {
        Airforces, Marines
    }
}