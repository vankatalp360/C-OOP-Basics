﻿public interface IIndentification
{
    string Id { get; }
}