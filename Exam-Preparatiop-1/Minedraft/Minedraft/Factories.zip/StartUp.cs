﻿using System;

class StartUp
{
    static void Main(string[] args)
    {
        var engine = new Engine();
        engine.Run();
    }
}