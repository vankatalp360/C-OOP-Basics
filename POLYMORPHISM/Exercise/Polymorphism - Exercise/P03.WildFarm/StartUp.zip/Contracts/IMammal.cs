﻿namespace P03.WildFarm.Contracts
{
    public interface IMammal
    {
        string LivingRegion { get; }
    }
}