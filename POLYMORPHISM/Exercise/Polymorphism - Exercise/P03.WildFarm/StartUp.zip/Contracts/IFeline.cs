﻿namespace P03.WildFarm.Contracts
{
    public interface IFeline
    {
        string Breed { get; }
    }
}