﻿namespace P03.WildFarm.Classes.Foods
{
    public class Meat : Food
    {
        public Meat(int quantity) 
            :base(quantity)
        {
        }
    }
}