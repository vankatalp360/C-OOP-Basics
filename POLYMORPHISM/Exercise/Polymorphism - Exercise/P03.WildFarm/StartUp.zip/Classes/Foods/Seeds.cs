﻿namespace P03.WildFarm.Classes.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity) 
            :base(quantity)
        {
        }
    }
}