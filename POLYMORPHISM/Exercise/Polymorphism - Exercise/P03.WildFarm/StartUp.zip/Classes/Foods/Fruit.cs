﻿namespace P03.WildFarm.Classes.Foods
{
    public class Fruit : Food
    {
        public Fruit()
        {
            
        }
        public Fruit(int quantity) 
            :base(quantity)
        {
        }
    }
}