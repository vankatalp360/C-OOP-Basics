﻿namespace Forum.App
{
    public interface IPositionable
    {
        Position Position { get; }
    }
}
