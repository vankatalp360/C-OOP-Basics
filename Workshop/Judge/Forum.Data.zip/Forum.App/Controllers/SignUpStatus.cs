﻿namespace Forum.App.Controllers
{
    public enum SignUpStatus
    {
        Success, DetailsError, UsernameTakenError
    }
}